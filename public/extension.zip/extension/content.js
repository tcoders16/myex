// ================== CONFIG ==================
const API_BASE = "https://myexbackend.onrender.com"; // your backend (enable CORS there)
const BTN_ID   = "__mail_extractor_float_btn";
const TOAST_ID = "__mail_extractor_toast";
// ============================================

// ---- Utils ----
const isVisible = el =>
  !!el && el.offsetParent !== null &&
  getComputedStyle(el).visibility !== "hidden" &&
  getComputedStyle(el).display !== "none";

const getText = el => (el?.innerText || "").trim();

function toast(msg, ok = true, ms = 1400) { /* ... keep your toast ... */ }

// ---- Floating Button ----
function ensureButton() {
  if (document.getElementById(BTN_ID)) return;

  // wrapper
  const wrap = document.createElement("div");
  wrap.id = BTN_ID;
  Object.assign(wrap.style, {
    position: "fixed",
    zIndex: "2147483647",
    right: "16px",
    bottom: "16px",
    width: "64px",
    height: "64px",
    display: "grid",
    placeItems: "center",
    borderRadius: "50%",
    boxShadow: "0 20px 50px rgba(2,6,23,0.35), 0 2px 10px rgba(2,6,23,0.25)",
    backdropFilter: "blur(6px)",
    pointerEvents: "none"
  });

  // actual button
  const btn = document.createElement("button");
  btn.type = "button";
  btn.title = "EX — Mail Event Extractor (Alt+E)";
  Object.assign(btn.style, {
    pointerEvents: "auto",
    width: "64px",
    height: "64px",
    border: "0",
    borderRadius: "50%",
    padding: "0",
    cursor: "pointer",
    background: "transparent",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    transition: "transform 0.2s ease, box-shadow 0.2s ease"
  });

  // logo image
  const img = document.createElement("img");
  img.src = chrome.runtime.getURL("icons/ex.png"); // <-- make sure ex.png is in /icons/
  img.alt = "EX Logo";
  Object.assign(img.style, {
    width: "60%",
    height: "60%",
    objectFit: "contain",
    borderRadius: "50%"
  });

  btn.appendChild(img);

  // hover / click animations
  btn.addEventListener("mouseenter", () => {
    btn.style.transform = "scale(1.08)";
    btn.style.boxShadow = "0 12px 28px rgba(0,0,0,0.35)";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.transform = "scale(1)";
    btn.style.boxShadow = "none";
  });
  btn.addEventListener("mousedown", () => {
    btn.style.transform = "scale(0.95)";
  });
  btn.addEventListener("mouseup", () => {
    btn.style.transform = "scale(1.08)";
  });

  // click triggers extractor
  btn.addEventListener("click", handleExtractClick);

  // assemble
  wrap.appendChild(btn);
  document.documentElement.appendChild(wrap);

  // Alt+E shortcut
  window.addEventListener("keydown", (e) => {
    if (e.altKey && (e.key === "e" || e.key === "E")) {
      e.preventDefault();
      handleExtractClick();
    }
  });
}

// ---- Toast Notifications ----
function ensureToast() {
  if (document.getElementById(TOAST_ID)) return;
  const el = document.createElement("div");
  el.id = TOAST_ID;
  Object.assign(el.style, {
    position: "fixed",
    zIndex: "2147483647",
    right: "16px",
    bottom: "92px",
    maxWidth: "360px",
    padding: "10px 12px",
    borderRadius: "12px",
    fontFamily: "Inter, system-ui, sans-serif",
    fontSize: "13px",
    fontWeight: "600",
    color: "#0b1020",
    background: "rgba(255,255,255,0.95)",
    boxShadow: "0 14px 40px rgba(2,6,23,0.25), 0 2px 8px rgba(2,6,23,0.18)",
    border: "1px solid rgba(2,6,23,0.08)",
    backdropFilter: "blur(6px)",
    transform: "translateY(8px)",
    opacity: "0",
    transition: "opacity .18s ease, transform .18s ease",
    display: "none",
    pointerEvents: "none",
    whiteSpace: "pre-wrap",
    lineHeight: "1.25"
  });
  document.documentElement.appendChild(el);
}

function toast(msg, ok = true, ms = 1400) {
  ensureToast();
  const el = document.getElementById(TOAST_ID);
  if (!el) return;

  el.textContent = msg;
  el.style.display = "block";
  el.style.borderColor = ok ? "rgba(16,185,129,.35)" : "rgba(244,63,94,.35)";
  el.style.boxShadow = ok
    ? "0 14px 40px rgba(16,185,129,.25), 0 2px 8px rgba(2,6,23,.18)"
    : "0 14px 40px rgba(244,63,94,.25), 0 2px 8px rgba(2,6,23,.18)";
  el.style.transform = "translateY(0)";
  el.style.opacity = "1";

  clearTimeout(el.__hideTimer);
  el.__hideTimer = setTimeout(() => {
    el.style.opacity = "0";
    el.style.transform = "translateY(8px)";
    setTimeout(() => { el.style.display = "none"; }, 220);
  }, ms);
}

// ---- Gmail scraper ----
function scrapeGmail() {
  const provider = "gmail"; 
  const url = location.href;

  const subject = getText(document.querySelector("h2.hP")) || getText(document.querySelector(".hP"));

  const fromNode = document.querySelector(".gD");
  const from = fromNode ? {
    name: fromNode.getAttribute("name") || fromNode.textContent?.trim(),
    email: fromNode.getAttribute("email") || fromNode.getAttribute("data-hovercard-id") || undefined
  } : undefined;

  const toNodes = [...document.querySelectorAll(".g2")];
  const to = toNodes.map(n => ({
    name: n.getAttribute("name") || n.textContent?.trim(),
    email: n.getAttribute("email") || n.getAttribute("data-hovercard-id") || undefined
  })).filter(x => x.email || x.name);

  const ccNodes = [...document.querySelectorAll(".g3")];
  const cc = ccNodes.map(n => ({
    name: n.getAttribute("name") || n.textContent?.trim(),
    email: n.getAttribute("email") || n.getAttribute("data-hovercard-id") || undefined
  })).filter(x => x.email || x.name);

  let sentAtISO;
  const timeEl = document.querySelector("span.g3 time") || document.querySelector("span.g3");
  const t = timeEl?.getAttribute?.("title") || timeEl?.getAttribute?.("datetime") || timeEl?.textContent;
  if (t) {
    const parsed = Date.parse(t);
    if (Number.isFinite(parsed)) sentAtISO = new Date(parsed).toISOString();
  }

  const bodies = [...document.querySelectorAll(".a3s")].filter(isVisible);
  const text = bodies.length
    ? bodies.map(n => getText(n)).filter(Boolean).join("\n\n---\n\n")
    : (getText(document.querySelector("main, article")) || getText(document.body));

  return { provider, url, subject, from, to, cc, sentAtISO, text };
}

// ---- Outlook scraper ----
function scrapeOutlook() {
  const provider = "outlook";
  const url = location.href;

  const subject =
    getText(document.querySelector("[data-testid='messageSubject']")) ||
    getText(document.querySelector("[role='heading']"));

  const fromName = getText(document.querySelector("[data-testid='messageSender']")) ||
                   getText(document.querySelector("[data-log-name='From']"));
  const from = fromName ? { name: fromName } : undefined;

  const to = [...document.querySelectorAll("[data-log-name='To'] [role='button'], [data-log-name='To'] a")]
    .map(n => ({ name: n.textContent?.trim() }))
    .filter(x => x.name);

  const cc = [...document.querySelectorAll("[data-log-name='Cc'] [role='button'], [data-log-name='Cc'] a")]
    .map(n => ({ name: n.textContent?.trim() }))
    .filter(x => x.name);

  let sentAtISO;
  const timeEl = document.querySelector("time") || document.querySelector("[data-testid='SentTime']");
  const t = timeEl?.getAttribute?.("datetime") || timeEl?.getAttribute?.("title") || timeEl?.textContent;
  if (t) {
    const parsed = Date.parse(t);
    if (Number.isFinite(parsed)) sentAtISO = new Date(parsed).toISOString();
  }

  const body =
    getText(document.querySelector('[role="document"]')) ||
    getText(document.querySelector("main, article")) ||
    getText(document.body);

  return { provider, url, subject, from, to, cc, sentAtISO, text: body };
}

// ---- Generic fallback ----
function scrapeGeneric() {
  return {
    provider: "generic",
    url: location.href,
    subject: document.title,
    text: getText(document.querySelector("main, article")) || getText(document.body),
  };
}

function detectProvider() {
  const h = location.hostname;
  if (h.includes("mail.google.com")) return "gmail";
  if (h.includes("outlook.live.com") || h.includes("outlook.office.com")) return "outlook";
  return "generic";
}

function scrapeCurrent() {
  const p = detectProvider();
  if (p === "gmail") return scrapeGmail();
  if (p === "outlook") return scrapeOutlook();
  return scrapeGeneric();
}

// ---- Click handler ----
async function handleExtractClick() {
  try {
    toast("Sending to extractor…", true, 1200);

    const page = scrapeCurrent();
    if (!page.text) {
      toast("No visible text found on this page.", false, 2000);
      return;
    }

    const payload = {
      text: page.text,
      subject: page.subject,
      from: page.from,
      to: page.to,
      cc: page.cc,
      provider: page.provider,
      url: page.url,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      referenceDate: page.sentAtISO || new Date().toISOString(),
      llmFirst: true
    };

    console.log("Payload → /api/extract/:", payload);

    const res = await fetch(`${API_BASE}/api/extract/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`HTTP ${res.status}${text ? `: ${text}` : ""}`);
    }

    let data = null;
    try {
      data = await res.json();
    } catch {}

    const events =
      (data?.data?.events && Array.isArray(data.data.events) && data.data.events) ||
      (Array.isArray(data?.events) && data.events) ||
      [];
    const count = Array.isArray(events) ? events.length : Number(data?.count) || 0;

    const degraded = data?.data?.degraded ?? data?.degraded ?? false;
    const warnings = (data?.data?.warnings ?? data?.warnings) || [];

    let msg = count
      ? `Parsed ${count} event${count === 1 ? "" : "s"} ✅`
      : "Sent to extractor ✅";

    if (degraded) msg += " (degraded)";
    if (Array.isArray(warnings) && warnings.length)
      msg += ` • ${warnings.length} warning${warnings.length === 1 ? "" : "s"}`;

    toast(msg, true, 1800);

  } catch (e) {
    console.error("Extraction failed:", e);
    const msg = e?.message || String(e) || "Extraction failed";
    toast(`Extraction failed: ${msg}`, false, 2800);
  }
}

// ---- Init ----
ensureButton();
ensureToast();

(function observeRouteChanges(){
  let last = location.href;
  new MutationObserver(() => {
    if (last !== location.href) {
      last = location.href;
      ensureButton();
    }
  }).observe(document, { subtree: true, childList: true });
})();